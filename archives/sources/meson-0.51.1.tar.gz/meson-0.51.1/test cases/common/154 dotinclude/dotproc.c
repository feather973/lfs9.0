#include"stdio.h"

#ifndef WRAPPER_INCLUDED
#error The wrapper stdio.h was not included.
#endif

int main(int argc, char **argv) {
    printf("Eventually I got printed.\n");
    return 0;
}
