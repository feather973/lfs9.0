#ifndef FUNC_H__
#define FUNC_H__

int func();

#endif
