int func1_in_obj();

int main(int argc, char **argv) {
    return func1_in_obj();
}
