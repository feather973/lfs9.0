/* Use the <> include notation to force searching in include directories */
#include <main.h>

int main(int argc, char *argv[]) {
  if (somefunc() == 1984)
    return 0;
  return 1;
}
