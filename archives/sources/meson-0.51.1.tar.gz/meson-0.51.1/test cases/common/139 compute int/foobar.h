#ifndef __FOOBAR_H__
#define __FOOBAR_H__

#define FOOBAR_IN_FOOBAR_H    10

#endif /*__FOOBAR_H__*/
