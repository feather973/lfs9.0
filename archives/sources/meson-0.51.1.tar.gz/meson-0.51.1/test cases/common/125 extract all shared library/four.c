#include"extractor.h"

int func4() {
    return 4;
}
